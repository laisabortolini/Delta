// const db = require('./db');
		
// //Criacao da tabela postagens
// const Post = db.sequelize.define('postagens', {
//     titulo: {
//         type: db.Sequelize.STRING
//     },
//     conteudo: {
//         type: db.Sequelize.TEXT
//     }
// })

// Post.sync();

// module.exports = Post;