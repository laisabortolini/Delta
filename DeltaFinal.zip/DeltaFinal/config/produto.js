const db = require('../models/db');
const multer = require('multer');
const path = require('path');

// Multer para o upload de imagens

const storage = multer.diskStorage({
    destination: (req,file,cb) => {
        cb(null, 'Images')
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: {fileSize: '1000000'},
    fileFilter:(req,file,cb) => {
        const fileTypes = /jpeg|png|jpg/
        const mimeType = fileTypes.test(file.mimetype)
        const extname = fileTypes.test(path.extname(file.originalname))

        if(mimeType && extname) {
            return cb(null,true)
        }
        cb('Give proper files formate to upload')
    }
}).fields([
    {name: 'imagem1',maxCount: 1},
    {name: 'imagem2',maxCount: 1},
    {name: 'imagem3',maxCount: 1}
])

module.exports = {
    upload
}