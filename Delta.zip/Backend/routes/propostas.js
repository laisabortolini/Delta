const express = require('express');
const router = express.Router();
const sequelize = require('sequelize');
const passport = require("passport");
const configprod = require('../config/produto.js');
const Produto = require('../models/Produto.js');
const path = require('path');
const flash = require("connect-flash");
const Categoria = require('../models/Categoria.js');
const Usuario = require('../models/Usuario.js');
const Item = require('../models/Item.js')
const Personalizacao = require('../models/Personalizacao.js')
const Pedido = require('../models/Pedido.js')
const Status = require('../models/Status.js')

router.get('/enviar', (req, res) => 
{
    Produto.findOne({where:{id: req.query.produto}}).then((produto) => {
        res.render('propostas/enviar',{produto: produto,vendedor: req.query.vendedor});
    })
});

router.post('/cadProposta',configprod.upload, (req,res) =>
{
    let errors = [];

    if (!req.body.espProposta || typeof req.body.espProposta == null || typeof req.body.espProposta == undefined || typeof req.body.espProposta == Number) errors.push({ text: "Especificacoes inválidas" });

    if(errors.length > 0){

    }else{
        const novaPersonalizacao = {
            especificacoes: req.body.espProposta,
            imgProposta1: req.files['imagem1'][0].path,
            imgProposta2: req.files['imagem2'][0].path,
            imgProposta3: req.files['imagem3'][0].path,
            usuarioVendedor: req.body.vendedor,
            UsuarioId: req.user.id,
            ProdutoId: req.body.produto,
            status: "Aguardando resposta"
        }
        
        Personalizacao.create(novaPersonalizacao).then(function()
        {
            res.flash("success_msg","Personalizacao enviada com sucesso!")
            res.redirect('/');
        }).catch(function(erro){
            req.flash("error_msg","Houve um erro ao enviar")
            res.redirect("/");
        })
    }
})
  
//   app.get('/receber-formulario', (req, res) => {
//     const form = users[2].forms[users[2].forms.length - 1];
//     res.send(`
//       <html>
//       <body>
//         <h1>Novo Formulário</h1>
//         <form action="/responder-formulario" method="get">
//           <input type="hidden" name="id" value="2">
//           <label for="title">Título:</label>
//           <input type="text" id="title" name="title" value="${form.title}" readonly><br><br>
//           <label for="message">Mensagem:</label>
//           <input type="text" id="message" name="message" value="${form.message}" readonly><br><br>
//           <label for="image">Imagem:</label>
//           <img src="${form.image}" alt="Imagem" style="max-width: 300px;"><br><br>
//           <input type="submit" value="Responder">
//         </form>
//       </body>
//       </html>
//     `);
//   });
  
//   app.get('/responder-formulario', (req, res) => {
//     const userId = req.query.id;
//     const { title, message, image } = req.query;
  
//     if (userId === '2') {
//       const form = { title, message, image };
//       users[1].forms.push(form);
//       res.send('Formulário enviado com sucesso!');
//     } else {
//       res.status(403).send('Acesso negado');
//     }
//   });
  
//   app.get('/receber-resposta', (req, res) => {
//     const form = users[1].forms[users[1].forms.length - 1];
//     res.send(`
//       <html>
//       <body>
//         <h1>Resposta do Formulário</h1>
//         <form action="/aceitar-ou-recusar" method="get">
//           <input type="hidden" name="id" value="1">
//           <label for="title">Título:</label>
//           <input type="text" id="title" name="title" value="${form.title}" readonly><br><br>
//           <label for="message">Mensagem:</label>
//           <input type="text" id="message" name="message" value="${form.message}" readonly><br><br>
//           <label for="image">Imagem:</label>
//           <img src="${form.image}" alt="Imagem" style="max-width: 300px;"><br><br>
//           <label for="accept">Aceitar:</label>
//           <input type="radio" id="accept" name="status" value="accept" required>
//           <label for="reject">Recusar:</label>
//           <input type="radio" id="reject" name="status" value="reject" required><br><br>
//           <input type="submit" value="Enviar">
//         </form>
//       </body>
//       </html>
//     `);
//   });
  
//   app.get('/aceitar-ou-recusar', (req, res) => {
//     const userId = req.query.id;
//     const status = req.query.status;
  
//     if (userId === '1') {
//       if (status === 'accept') {
//         res.send('Formulário aceito!');
//       } else if (status === 'reject') {
//         res.send('Formulário recusado!');
//       } else {
//         res.status(400).send('Status inválido');
//       }
//     } else {
//       res.status(403).send('Acesso negado');
//     }
//   });

module.exports = router;