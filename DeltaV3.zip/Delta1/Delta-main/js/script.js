function AtributosJ(checkbox) {
    if(checkbox.checked == true){
        document.getElementById("atributosfisica").classList.toggle('d-none');
        document.getElementById("atributosjuridica").classList.remove('d-none');
    }else{
        document.getElementById("atributosfisica").classList.remove('d-none');
        document.getElementById("atributosjuridica").classList.toggle('d-none');
   }
}
