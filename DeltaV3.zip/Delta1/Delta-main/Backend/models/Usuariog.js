const db = require('./db');

const GUser = db.sequelize.define('GUser', {
    googleId: { type: db.Sequelize.STRING},
    displayName: { type: db.Sequelize.STRING}
    // Outros campos do perfil do usuário que você deseja salvar
  });
  
  // Sincronize o modelo com o banco de dados
  GUser.sync().then(() => {
    console.log('Modelo GUser sincronizado com sucesso com o banco de dados.');
  }).catch((error) => {
    console.error('Erro ao sincronizar o modelo GUser com o banco de dados:', error);
  });
  
  module.exports = GUser;