const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
require("../models/usuario");
const Usuario = mongoose.model("Usuario");
const bcrypt = require("bcrypt");
const passport = require("passport");

router.get("/cadastro", (req, res) => {
    res.render("users/cadastro")
});

router.post("/cadastro", (req, res) => {
    let errors = [];

    if (!req.body.nome) errors.push({ text: "Nome inválido." });

    if (!req.body.cpf) errors.push({ text: "CPF inválido." });

    if (!req.body.datanasc) errors.push({ text: "Data de nascimento inválida." });

    if (!req.body.telefone) errors.push({ text: "Telefone inválido." });

    if (!req.body.email) errors.push({ text: "Email inválido." });

    if (!req.body.senha) errors.push({ text: "Senha inválida." });

    if (req.body.email != req.body.cemail)
        errors.push({ text: "Emails não são iguais." });

    if (req.body.senha != req.body.csenha)
        errors.push({ text: "Senhas não são iguais." });

    if (errors.length > 0) {
        res.render("users/cadastro", {
            errors: errors,
            nome: req.body.nome,
            cpf: req.body.cpf,
            datanasc: req.body.datanasc,
            telefone: req.body.telefone,
            email: req.body.email,
            cemail: req.body.cemail,
            senha: req.body.senha,
            csenha: req.body.csenha,
        });
    } else {
        Usuario.findOne({ Email: req.body.email })
            .then((usuario) => {
                if (usuario) {
                    req.flash("error_msg", "Email já registrado.");
                    res.redirect("/usuario/cadastro");
                } else {
                    const newUser = new Usuario({
                        Nome: req.body.nome,
                        CPF: req.body.cpf,
                        dataNascimento: req.body.datanasc,
                        Telefone: req.body.telefone,
                        Email: req.body.email,
                        Senha: req.body.senha,
                    });

                    bcrypt.genSalt(10, (err, salt) => {
                        bcrypt.hash(newUser.Senha, salt, (err, hash) => {
                            if (err) {
                                req.flash("error_msg", "Erro no cadastro.");
                                res.redirect("/usuario/cadastro");
                            }
                            newUser.Senha = hash;
                            newUser
                                .save()
                                .then(() => {
                                    req.flash(
                                        "success_msg",
                                        "Você foi cadastrado.",
                                    );
                                    res.redirect("/usuario/login");
                                })
                                .catch((err) => {
                                    console.log(err);
                                });
                        });
                    });
                }
            })
            .catch((err) => {
                req.flash("error_msg", "Algo deu errado.");
                res.redirect("/usuario/cadastro");
            });
    }
});

router.get("/login", (req, res) => {
    res.render("users/login");
});

router.post("/login", (req, res, next) => {
    const { email, senha } = req.body;

    passport.authenticate("local", {
        successRedirect: "/usuario/cadastro",
        failureRedirect: "/usuario/login",
        failureFlash: true,
    })(req, res, next);
});

router.get("/logout", (req, res) => {
    req.logout();
    req.flash("success_msg", "Você saiu.");
    res.redirect("/usuario/login");
});

// Rota de autenticação com o Google
router.get('/auth/google',
    passport.authenticate('google', { scope: ['profile'] })
);

// Rota de callback do Google após a autenticação
router.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/usuario/cadastro' }),
    (req, res) => {
        // Redirecionar para a página de sucesso após a autenticação
        res.redirect('/usuario/login');
    }
);

// Rota de sucesso após a autenticação
router.get('/usuario/login', (req, res) => {
    res.send('Autenticação bem-sucedida!');
});

module.exports = router;