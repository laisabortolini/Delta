const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mongoose = require("mongoose");

require("../models/usuario");

var passport = require('passport');

const GUser = mongoose.model('GUser');

module.exports = (passport) => {
    passport.use("google", new GoogleStrategy({
      clientID: '1079931794664-3ohne9brfkh1cr1fm0sd6acj51ctmsjj.apps.googleusercontent.com',
      clientSecret: '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',
      callbackURL: '/usuario/auth/google/callback'
    }, async (accessToken, refreshToken, profile, done) => {
      try {
        const existingUser = await GUser.findOne({ googleId: profile.id });
        
        if (existingUser) {
          // O usuário já está registrado, retorne o objeto do usuário existente
          return done(null, existingUser);
        }
        
        // O usuário não está registrado, crie um novo usuário com os dados do perfil
        const newUser = new GUser({
          googleId: profile.id,
          displayName: profile.displayName
          // Atribua outros campos do perfil do usuário, se necessário
        });
  
        // Salve o novo usuário no MongoDB
        const savedUser = await newUser.save();
        // Retorne o objeto do usuário recém-criado
        return done(null, savedUser);
      } catch (err) {
        return done(err);
      }
    }));
  }