const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const { default: mongoose } = require("mongoose");
require("../models/usuario");
const GUser = mongoose.model('GUser', GUserSchema);

passport.use(new GoogleStrategy({
    clientID: '1079931794664-3ohne9brfkh1cr1fm0sd6acj51ctmsjj.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: '/auth/google/callback'
}, (accessToken, refreshToken, profile, done) => {
    GUser.findOne({ googleId: profile.id }, (err, existingUser) => {
        if (err) {
          return done(err);
        }
    
        if (existingUser) {
          // O usuário já está registrado, retorne o objeto do usuário existente
          return done(null, existingUser);
        }
    
        // O usuário não está registrado, crie um novo usuário com os dados do perfil
        const newUser = new GUser({
          googleId: profile.id,
          displayName: profile.displayName
          // Atribua outros campos do perfil do usuário, se necessário
        });
    
        // Salve o novo usuário no MongoDB
        newUser.save((err, savedUser) => {
          if (err) {
            return done(err);
          }
          // Retorne o objeto do usuário recém-criado
          return done(null, savedUser);
        });
      });
}));

