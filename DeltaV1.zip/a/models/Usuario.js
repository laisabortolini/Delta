//const db = require('./db');
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//Criacao da tabela usuarios
/* const Usuario = db.sequelize.define('clientes', {
    Nome:
    { type: db.Sequelize.STRING},
    CPF: 
    { type : db.Sequelize.STRING },
    dataNascimento:
    { type : db.Sequelize.DATE },
    Telefone:
    { type : db.Sequelize.STRING },
    Email:
    { type : db.Sequelize.STRING },
    Senha:
    { type: db.Sequelize.STRING }
}
) */

const Usuario = new Schema({
    Nome: { 
        type: String,
        required: true
    },
    CPF: { 
        type : String,
        required: true 
    },
    dataNascimento: { 
        type : Date,
        required: true 
    },
    Telefone: { 
        type : String,
        required: true
    },
    Email: { 
        type : String, 
        required: true
    },
    Senha: { 
        type: String,
        required: true 
    },
});

// Usuario.sync();

// module.exports = Usuario;
mongoose.model("Usuario", Usuario);