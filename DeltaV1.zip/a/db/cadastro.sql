CREATE TABLE usuarios(
    nome VARCHAR(50),
    email VARCHAR(50),
    idade INT
);