const express = require("express");
const res = require("express/lib/response");
const path = require('path');
const app = express();
const handlebars = require('express-handlebars');
const bodyParser = require('body-parser');
const Post = require('./models/Post.js');
const usuario = require("./routes/usuarios");
const session = require("express-session");
const passport = require("passport");
require("./config/auth")(passport);
const flash = require("connect-flash");
const { default: mongoose } = require("mongoose");
const db = require("./config/db");

//Session
app.use(
    session({
        secret: "secret",
        resave: true,
        saveUninitialized: true,
    }),
);

app.use(passport.initialize());
app.use(passport.session());

app.use(flash());

// Middleware
app.use((req, res, next) => {
    res.locals.success_msg = req.flash("success_msg");
    res.locals.error_msg = req.flash("error_msg");
    res.locals.error = req.flash("error");
    res.locals.user = req.user || null;
    next();
});

// Config
    // Template Engine
        app.engine('handlebars', handlebars.engine({defaultLayout: 'main'}))
        app.set('view engine','handlebars');
        app.set("views", "views");
        mongoose
            .connect(db.mongURI)
            .then(() => console.log("Connected to MongoDB"))
            .catch((err) => console.log("Error connecting" + err));
    //Body Parser
        app.use(bodyParser.urlencoded({extended: false}))
        app.use(bodyParser.json());
        app.use(express.static(path.join(__dirname + '/public')));
// Rotas
        app.get('/', function(req,res){
            Post.findAll().then(function(posts){
                res.render('home',{posts: posts})
            })
        })

        app.get('users/cadastro',function(req,res){
            res.render('cadastro');
        })

        app.get('/cadpost', function(req,res){
            res.render('formulario');
        })

        // app.post('/cadusuario',function(req,res){
        //     Usuario.create({
        //         Nome: req.body.nome,
        //         CPF: req.body.cpf,
        //         dataNascimento: req.body.datanasc,
        //         Telefone: req.body.telefone,
        //         Email: req.body.email,
        //         Senha: req.body.senha
        //     }).then(function(){
        //         res.redirect('/')
        //     }).catch(function(erro){
        //         res.send("Houve um erro: " + erro);
        //     })
        // })

        app.use("/usuario", usuario);

        app.post('/add', function(req, res){
            Post.create({
                titulo: req.body.titulo,
                conteudo: req.body.conteudo
            }).then(function(){
                res.redirect('/')
            }).catch(function(erro){
                res.send("Houve um erro: " + erro)
            })
        })


/* app.get("/",function(req,res){
    res.sendFile(__dirname + "/html/index.html");
});

app.get("/sobre", function(req, res){
    res.send("Minha pagina sobre");
});

app.get("/blog", function(req, res){
    res.send("Meu blog");
});

app.get("/ola/:nome/:cargo/:cor", function(req, res){
    res.send(`<h1>Ola ${req.params.nome}</h1>`+`<h2>Seu cargo e: ${req.params.cargo}</h2>`+`<h2>Sua cor e: ${req.params.cor}</h2>`);

});
*/

app.listen(8081,function(){
    console.log("Servidor Rodando");
}); 

